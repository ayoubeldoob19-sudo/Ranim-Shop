const fs = require("fs"), path = require("path"), crypto = require("crypto");
const express = require("express"), { Pool } = require("pg");
const E = process.env, PORT = E.PORT || 3000, PROD = E.NODE_ENV === "production";

["DATABASE_URL", "ADMIN_PASSWORD", "SESSION_SECRET", "CLOUDINARY_CLOUD_NAME", "CLOUDINARY_API_KEY", "CLOUDINARY_API_SECRET"]
  .forEach(k => { if (!E[k]) { console.error("Missing env var: " + k); process.exit(1); } });

const pool = new Pool({ connectionString: E.DATABASE_URL, ssl: { rejectUnauthorized: false }, max: 5 });
const app = express();
app.set("trust proxy", 1);
app.disable("x-powered-by");
app.use((q, s, n) => {
  s.set({ "X-Content-Type-Options": "nosniff", "Referrer-Policy": "strict-origin-when-cross-origin", "X-Frame-Options": "DENY" });
  n();
});
app.use(express.json({ limit: "100kb" }));
// Mutating requests must be JSON: a cross-site form cannot send that.
app.use((q, s, n) => {
  if (q.method !== "GET" && q.method !== "HEAD" && !q.is("json")) return s.status(415).json({ error: "json" });
  n();
});

/* ---------- helpers ---------- */
const hits = new Map();
const rl = (max, ms) => (q, s, n) => {
  const k = q.ip + q.path, now = Date.now(), h = hits.get(k) || { n: 0, t: now };
  if (now - h.t > ms) { h.n = 0; h.t = now; }
  h.n++; hits.set(k, h);
  if (h.n > max) return s.status(429).json({ error: "rate" });
  n();
};
setInterval(() => { const now = Date.now(); for (const [k, h] of hits) if (now - h.t > 3600000) hits.delete(k); }, 600000).unref();

const wrap = f => (q, s, n) => f(q, s, n).catch(e => { console.error(e); s.status(500).json({ error: "server" }); });
const str = (v, m) => (typeof v === "string" ? v.trim().slice(0, m) : "");
const int = (v, a, b) => { const n = Number(v); return v !== "" && v != null && Number.isInteger(n) && n >= a && n <= b ? n : null; };
const arr = x => (Array.isArray(x) ? x : []);
const CL = /^https:\/\/res\.cloudinary\.com\//;
const idp = q => int(q.params.id, 1, 2147483647);

/* ---------- admin session (signed cookie, no extra packages) ---------- */
const sign = d => crypto.createHmac("sha256", E.SESSION_SECRET).update(d).digest("base64url");
const mkToken = () => {
  const d = Buffer.from(JSON.stringify({ exp: Date.now() + 7 * 864e5 })).toString("base64url");
  return d + "." + sign(d);
};
const okToken = t => {
  try {
    const [d, s] = String(t).split(".");
    const a = Buffer.from(sign(d)), b = Buffer.from(s || "");
    return a.length === b.length && crypto.timingSafeEqual(a, b) && JSON.parse(Buffer.from(d, "base64url")).exp > Date.now();
  } catch { return false; }
};
const getCookie = q => ((q.headers.cookie || "").split(/;\s*/).find(c => c.startsWith("adm=")) || "").slice(4);
const auth = (q, s, n) => (okToken(getCookie(q)) ? n() : s.status(401).json({ error: "auth" }));
const same = (a, b) => {
  const h = x => crypto.createHash("sha256").update(String(x)).digest();
  return crypto.timingSafeEqual(h(a), h(b));
};

/* ---------- public API ---------- */
app.get("/api/health", (q, s) => s.json({ ok: true })); // does not touch the database on purpose

app.get("/api/products", wrap(async (q, s) => {
  const { rows } = await pool.query(
    "select id,name_ar,name_fr,desc_ar,desc_fr,price,badge,stock,images,opts from products where active order by position,id");
  s.set("Cache-Control", "public, max-age=30");
  s.json(rows.map(({ stock, ...p }) => ({ ...p, badge: stock !== null && stock <= 0 ? "out" : p.badge })));
}));

app.get("/api/reviews", wrap(async (q, s) => {
  const { rows } = await pool.query("select id,image_url,text_ar,text_fr,who from reviews where active order by position,id");
  s.set("Cache-Control", "public, max-age=60");
  s.json(rows);
}));

app.post("/api/orders", rl(10, 600000), wrap(async (q, s) => {
  const b = q.body || {};
  const qty = int(b.qty, 1, 10), pid = int(b.product_id, 1, 2147483647);
  const name = str(b.name, 80), phone = String(b.phone || "").replace(/[\s.-]/g, "");
  const wilaya = str(b.wilaya, 60), commune = str(b.commune, 60), address = str(b.address, 200), options = str(b.options, 200);
  const delivery = b.delivery === "desk" ? "desk" : "home";
  if (!qty || !pid || name.length < 3 || !/^0[567]\d{8}$/.test(phone) || !wilaya || (delivery === "home" && !address))
    return s.status(400).json({ error: "invalid" });
  // Price and stock come from the database, never from the browser. The update is atomic.
  const r = await pool.query(
    "update products set stock = stock - $1 where id=$2 and active and (stock is null or stock >= $1) returning name_ar, price",
    [qty, pid]);
  if (!r.rows[0]) return s.status(409).json({ error: "unavailable" });
  const p = r.rows[0];
  await pool.query(
    "insert into orders(product_id,product_name,options,qty,unit_price,total,name,phone,wilaya,commune,delivery,address) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)",
    [pid, p.name_ar, options, qty, p.price, p.price * qty, name, phone, wilaya, commune, delivery, address]);
  s.status(201).json({ ok: true });
}));

app.post("/api/event", rl(120, 60000), wrap(async (q, s) => {
  const type = q.body && q.body.type;
  if (!["visit", "product_view", "ig_click", "call_click"].includes(type)) return s.status(400).json({ error: "type" });
  await pool.query("insert into events(type,product_id) values($1,$2)", [type, int(q.body.product_id, 1, 2147483647)]);
  s.json({ ok: true });
}));

/* ---------- admin API ---------- */
app.post("/api/admin/login", rl(8, 900000), (q, s) => {
  if (!same(q.body && q.body.password, E.ADMIN_PASSWORD)) return s.status(401).json({ error: "bad" });
  s.cookie("adm", mkToken(), { httpOnly: true, sameSite: "lax", secure: PROD, maxAge: 7 * 864e5, path: "/" });
  s.json({ ok: true });
});
app.post("/api/admin/logout", (q, s) => { s.clearCookie("adm", { path: "/" }); s.json({ ok: true }); });
app.use("/api/admin", auth);
app.get("/api/admin/me", (q, s) => s.json({ ok: true }));

const P = b => {
  const opts = arr(b.opts).slice(0, 3).map(o => {
    const v = arr(o && o.v).map(x => str(x, 30)).filter(Boolean).slice(0, 12);
    const vf = arr(o && o.vf).map(x => str(x, 30));
    return { ar: str(o && o.ar, 30), fr: str(o && o.fr, 30) || str(o && o.ar, 30), v, vf: v.map((x, i) => vf[i] || x) };
  }).filter(o => o.ar && o.v.length);
  return {
    name_ar: str(b.name_ar, 80), name_fr: str(b.name_fr, 80), desc_ar: str(b.desc_ar, 1000), desc_fr: str(b.desc_fr, 1000),
    price: int(b.price, 0, 10000000),
    badge: ["best", "new", "out"].includes(b.badge) ? b.badge : "",
    stock: b.stock === "" || b.stock == null ? null : int(b.stock, 0, 100000),
    active: b.active !== false,
    images: arr(b.images).filter(u => typeof u === "string" && CL.test(u)).slice(0, 8),
    opts
  };
};
const PV = p => [p.name_ar, p.name_fr, p.desc_ar, p.desc_fr, p.price, p.badge, p.stock, JSON.stringify(p.images), JSON.stringify(p.opts), p.active];

app.get("/api/admin/products", wrap(async (q, s) => s.json((await pool.query("select * from products order by position,id")).rows)));

app.post("/api/admin/products/reorder", wrap(async (q, s) => {
  const ids = arr(q.body.ids).map(x => int(x, 1, 2147483647)).filter(Boolean);
  if (!ids.length) return s.status(400).json({ error: "invalid" });
  await pool.query(
    "update products p set position=t.ord from unnest($1::int[]) with ordinality as t(id,ord) where p.id=t.id", [ids]);
  s.json({ ok: true });
}));

app.post("/api/admin/products", wrap(async (q, s) => {
  const p = P(q.body || {});
  if (!p.name_ar || p.price === null) return s.status(400).json({ error: "invalid" });
  if ((await pool.query("select count(*)::int n from products")).rows[0].n >= 10) return s.status(409).json({ error: "max" });
  const r = await pool.query(
    "insert into products(name_ar,name_fr,desc_ar,desc_fr,price,badge,stock,images,opts,active,position) values($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,(select coalesce(max(position),0)+1 from products)) returning *",
    PV(p));
  s.status(201).json(r.rows[0]);
}));

app.put("/api/admin/products/:id", wrap(async (q, s) => {
  const id = idp(q), p = P(q.body || {});
  if (!id || !p.name_ar || p.price === null) return s.status(400).json({ error: "invalid" });
  const r = await pool.query(
    "update products set name_ar=$1,name_fr=$2,desc_ar=$3,desc_fr=$4,price=$5,badge=$6,stock=$7,images=$8,opts=$9,active=$10 where id=$11 returning *",
    [...PV(p), id]);
  r.rows[0] ? s.json(r.rows[0]) : s.status(404).json({ error: "nf" });
}));

app.delete("/api/admin/products/:id", wrap(async (q, s) => {
  await pool.query("delete from products where id=$1", [idp(q)]);
  s.json({ ok: true });
}));

app.get("/api/admin/orders", wrap(async (q, s) =>
  s.json((await pool.query("select * from orders order by id desc limit 200")).rows)));

app.put("/api/admin/orders/:id", wrap(async (q, s) => {
  const st = q.body && q.body.status;
  if (!["new", "confirmed", "shipping", "delivered", "canceled"].includes(st)) return s.status(400).json({ error: "invalid" });
  await pool.query("update orders set status=$1 where id=$2", [st, idp(q)]);
  s.json({ ok: true });
}));

const RV = b => ({
  image_url: CL.test(str(b.image_url, 500)) ? str(b.image_url, 500) : "",
  text_ar: str(b.text_ar, 400), text_fr: str(b.text_fr, 400), who: str(b.who, 60)
});
app.get("/api/admin/reviews", wrap(async (q, s) => s.json((await pool.query("select * from reviews order by position,id")).rows)));
app.post("/api/admin/reviews", wrap(async (q, s) => {
  const r = RV(q.body || {});
  if (!r.image_url && !r.text_ar) return s.status(400).json({ error: "invalid" });
  const x = await pool.query(
    "insert into reviews(image_url,text_ar,text_fr,who,position) values($1,$2,$3,$4,(select coalesce(max(position),0)+1 from reviews)) returning *",
    [r.image_url, r.text_ar, r.text_fr, r.who]);
  s.status(201).json(x.rows[0]);
}));
app.delete("/api/admin/reviews/:id", wrap(async (q, s) => {
  await pool.query("delete from reviews where id=$1", [idp(q)]);
  s.json({ ok: true });
}));

app.get("/api/admin/stats", wrap(async (q, s) => {
  const w = "created_at > now() - interval '30 days'";
  const [t, daily, viewed, ordered, o] = await Promise.all([
    pool.query(`select type, count(*)::int n from events where ${w} group by type`),
    pool.query(`select to_char(date_trunc('day',created_at),'MM-DD') d, count(*)::int n from events where type='visit' and ${w} group by 1 order by 1`),
    pool.query(`select p.name_ar, count(*)::int n from events e join products p on p.id=e.product_id where e.type='product_view' and e.${w} group by p.id order by n desc limit 5`),
    pool.query("select product_name, sum(qty)::int q from orders where status<>'canceled' group by product_name order by q desc limit 5"),
    pool.query("select count(*)::int n, count(*) filter (where status='new')::int fresh, coalesce(sum(total) filter (where status='delivered'),0)::int rev from orders")
  ]);
  s.json({
    t: Object.fromEntries(t.rows.map(r => [r.type, r.n])),
    daily: daily.rows, viewed: viewed.rows, ordered: ordered.rows, o: o.rows[0]
  });
}));

// Browser uploads straight to Cloudinary using this short-lived signature; the secret never leaves the server.
app.post("/api/admin/upload-sign", (q, s) => {
  const ts = Math.floor(Date.now() / 1000), folder = "ranim";
  const sig = crypto.createHash("sha1").update(`folder=${folder}&timestamp=${ts}${E.CLOUDINARY_API_SECRET}`).digest("hex");
  s.json({ cloud: E.CLOUDINARY_CLOUD_NAME, key: E.CLOUDINARY_API_KEY, ts, folder, sig });
});

/* ---------- static site ---------- */
app.use("/admin", (q, s, n) => { s.set("X-Robots-Tag", "noindex"); n(); });
app.use(express.static(path.join(__dirname, "public"), { extensions: ["html"], maxAge: "5m" }));
app.use("/api", (q, s) => s.status(404).json({ error: "nf" }));
app.use((e, q, s, n) => { console.error(e.message); s.status(e.status || 500).json({ error: "server" }); });

(async () => {
  await pool.query(fs.readFileSync(path.join(__dirname, "schema.sql"), "utf8"));
  await pool.query("delete from events where created_at < now() - interval '180 days'");
  app.listen(PORT, () => console.log("Ranim Shop listening on " + PORT));
})().catch(e => { console.error(e); process.exit(1); });
