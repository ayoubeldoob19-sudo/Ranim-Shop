# Ranim Shop – دليل التشغيل (مجاني)

## الملفات
- `server.js`: الـ API والخادم
- `schema.sql`: جداول قاعدة البيانات (تتنشأ تلقائيا عند أول تشغيل)
- `public/index.html`: الموقع للزبائن
- `public/admin.html`: لوحة المدير (الرابط: `/admin`)

## 1) GitHub
1. أنشئ Repository جديد (Private).
2. اضغط **Add file → Upload files** وارفع **محتوى** هذا المجلد (server.js، package.json، schema.sql، مجلد public، .gitignore). لا ترفع ملف `.env` أبدا.

## 2) Neon (قاعدة البيانات)
1. أنشئ مشروع جديد.
2. من **Connection Details** انسخ الـ **Connection string** (فيها `sslmode=require`). هذا هو `DATABASE_URL`.

## 3) Cloudinary (الصور)
من **Dashboard** انسخ: Cloud name وAPI Key وAPI Secret.

## 4) Render
1. **New → Web Service** وصل مع الـ Repository.
2. الإعدادات:
   - Runtime: **Node**
   - Build Command: `npm install`
   - Start Command: `npm start`
   - Instance Type: **Free**
3. من **Environment** زيد هذه المتغيرات:

| الاسم | القيمة |
|---|---|
| `DATABASE_URL` | الرابط من Neon |
| `ADMIN_PASSWORD` | كلمة سر قوية تختارها (طويلة) |
| `SESSION_SECRET` | نص عشوائي طويل (30 حرف أو أكثر) |
| `CLOUDINARY_CLOUD_NAME` | من Cloudinary |
| `CLOUDINARY_API_KEY` | من Cloudinary |
| `CLOUDINARY_API_SECRET` | من Cloudinary |
| `NODE_ENV` | `production` |

4. اضغط Deploy. كي يخلص افتح `https://اسمك.onrender.com/admin` وادخل بكلمة السر.

## ملاحظات مهمة
- **الخدمة المجانية في Render تنام** بعد 15 دقيقة بلا زيارات، وأول زيارة بعدها تأخذ حوالي دقيقة. حل اختياري: خدمة مراقبة مجانية (مثل UptimeRobot) تفتح `/api/health` كل 5 دقائق. هذا الرابط ما يلمسش قاعدة البيانات، فما يستهلكش ساعات Neon.
- ما تشاركش `ADMIN_PASSWORD` ولا مفاتيح Cloudinary مع أي أحد، ولا ترسلهم في الدردشة.
- أقصى عدد للمنتجات 10. الطلبات تدخل في تبويب **الطلبات**.
- كل مرة تبدل الكود في GitHub، Render يعيد النشر تلقائيا.
