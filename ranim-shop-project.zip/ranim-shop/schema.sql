create table if not exists products(
  id serial primary key,
  name_ar text not null, name_fr text not null default '',
  desc_ar text not null default '', desc_fr text not null default '',
  price integer not null check(price>=0),
  badge text not null default '', stock integer,
  images jsonb not null default '[]', opts jsonb not null default '[]',
  position integer not null default 0, active boolean not null default true,
  created_at timestamptz not null default now());
create table if not exists orders(
  id serial primary key, product_id integer,
  product_name text not null, options text not null default '',
  qty integer not null, unit_price integer not null, total integer not null,
  name text not null, phone text not null, wilaya text not null,
  commune text not null default '', delivery text not null, address text not null default '',
  status text not null default 'new', created_at timestamptz not null default now());
create table if not exists reviews(
  id serial primary key, image_url text not null default '',
  text_ar text not null default '', text_fr text not null default '', who text not null default '',
  position integer not null default 0, active boolean not null default true,
  created_at timestamptz not null default now());
create table if not exists events(
  id bigserial primary key, type text not null, product_id integer,
  created_at timestamptz not null default now());
create index if not exists events_type_time on events(type, created_at);
create index if not exists orders_created on orders(created_at desc);
